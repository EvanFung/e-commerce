/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ict.db;
import ict.bean.GiftBean;
import ict.bean.GiftRecordBean;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/**
 *
 * @author Fujitsu-SING
 */
public class GiftRecordDB {
    private String url = "";
    private String username = "";
    private String password = "";
    
    
    public GiftRecordDB(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }
    
    public boolean addGiftRecord(String c_id,String g_id,String stuts){
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        boolean isSuccess = false;
        try {
            cnnct = getConnection();
            String preQueryStatement = "INSERT  INTO GiftRecord (coutomer_id, gift_id, status) VALUES  (?,?,?)";
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            pStmnt.setString(1, c_id);
            pStmnt.setString(2, g_id);
            pStmnt.setString(3, stuts);
            int rowCount = pStmnt.executeUpdate();
            if (rowCount >= 1) {
                isSuccess = true;
            }
            pStmnt.close();
            cnnct.close();
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return isSuccess;
    }
    public void createGiftRecordTable() throws SQLException, IOException {
        Connection cnnct = null;
        Statement stmnt = null;

        if (!tableExist(getConnection(), "GiftRecord")) {
            try {
                //if the table is existed.
                cnnct = getConnection();  // the connection 
                stmnt = cnnct.createStatement();  // create statement
                String sql = "CREATE TABLE GiftRecord ("
                        + "giftRecord_id INT NOT NULL GENERATED ALWAYS AS IDENTITY,"
                        + "coutomer_id integer NOT NULL,"
                        + "gift_id integer NOT NULL,"
                        + "status varchar(10) NOT NULL,"
                        + "CONSTRAINT pk_giftRecord_id PRIMARY KEY (giftRecord_id)"
                        + ")";

                stmnt.execute(sql);
                stmnt.close();
                cnnct.close();
            } catch (SQLException ex) {
                while (ex != null) {
                    ex.printStackTrace();
                    ex = ex.getNextException();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }

        } else {
            //if the table does not existed
            return;
        }

    }

    public ArrayList<GiftRecordBean> queryGifts(String status) {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        ArrayList<GiftRecordBean> list = new ArrayList<GiftRecordBean>();
        GiftRecordBean gb = null;
        try {
            cnnct = getConnection();
            String preQueryStatement = "SELECT * FROM GIFTRECORD WHERE STATUS LIKE ?";

            pStmnt = cnnct.prepareStatement(preQueryStatement);
            pStmnt.setString(1, status);
            ResultSet rs = null;
            rs = pStmnt.executeQuery();
            while (rs.next()) {

                gb = new GiftRecordBean();
                
                gb.setGr_id(rs.getInt(1));
                gb.setC_id(2);
                gb.setG_id(rs.getInt(3));
                gb.setStatus(rs.getString(4));

                list.add(gb);
            }
            pStmnt.close();
            cnnct.close();
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
    public boolean editStatus(int id, String status) {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        boolean isSuccess = false;
        try {
            cnnct = getConnection();
            String preQueryStatement = "UPDATE GIFTRECORD SET STATUS=? WHERE giftRecord_id=?";
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            pStmnt.setString(1, status);
            pStmnt.setInt(2, id);
            //Statement s = cnnct.createStatement();
            int rowCount = pStmnt.executeUpdate();
            if (rowCount >= 1) {
                isSuccess = true;
            }
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (pStmnt != null) {
                try {
                    pStmnt.close();
                } catch (SQLException e) {
                }
            }
            if (cnnct != null) {
                try {
                    cnnct.close();
                } catch (SQLException sqlEx) {
                }
            }
        }
        return isSuccess;
    }
    
    public Connection getConnection() throws SQLException, IOException {
        System.setProperty("jdbc.drivers", "org.apache.derby.jdbc.ClientDriver");
        return DriverManager.getConnection(url, username, password);
    }
    
    public boolean tableExist(Connection conn, String tableName) throws SQLException {
        boolean tExists = false;
        try (ResultSet rs = conn.getMetaData().getTables(null, null, tableName, null)) {
            while (rs.next()) {
                String tName = rs.getString("TABLE_NAME");
                if (tName != null && tName.equals(tableName)) {
                    tExists = true;
                    break;
                }
            }
        }
        return tExists;
    }
    
}
