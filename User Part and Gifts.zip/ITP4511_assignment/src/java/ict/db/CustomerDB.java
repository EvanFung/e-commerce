/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ict.db;

import ict.bean.CustomerBean;
import ict.bean.OrderBean;
import ict.bean.ProductBean;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class CustomerDB {

    private String url = "";
    private String username = "";
    private String password = "";

    public CustomerDB(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }

    public Connection getConnection() throws SQLException, IOException {
        System.setProperty("jdbc.drivers", "org.apache.derby.jdbc.ClientDriver");
        return DriverManager.getConnection(url, username, password);
    }

    public void createCustTable() throws SQLException, IOException {
        Connection cnnct = null;
        Statement stmnt = null;
        if (!tableExist(getConnection(), "CUSTOMER")) {
            try {
                cnnct = getConnection();  // the connection 
                stmnt = cnnct.createStatement();  // create statement
                String sql = "create table CUSTOMER ("
                        + "CustId int primary key generated always as identity, "
                        + "Password  VARCHAR(30),  "
                        + "Email  VARCHAR(30), "
                        + "First_name  VARCHAR(30), "
                        + "Last_name  VARCHAR(30), "
                        + "Gender  VARCHAR(1), "
                        + "bonusPoint INT,"
                        + "Address VARCHAR(100),"
                        + "role VARCHAR(30)"
                        + ")";
                stmnt.execute(sql);

                stmnt.close();
                cnnct.close();
            } catch (SQLException ex) {
                while (ex != null) {
                    ex.printStackTrace();
                    ex = ex.getNextException();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } else {
            return;
        }
    }

    public boolean addCustomer(String password, String email, String first_name, String last_name, String gender, String address,String role) {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        boolean isSuccess = false;
        try {
            cnnct = getConnection();
            String preQueryStatement = "INSERT  INTO  CUSTOMER (Email, Password, First_name, Last_name, Gender, Address,Role)  VALUES  (?,?,?,?,?,?,?)";
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            pStmnt.setString(1, email);
            pStmnt.setString(2, password);
            pStmnt.setString(3, first_name);
            pStmnt.setString(4, last_name);
            pStmnt.setString(5, gender);
            pStmnt.setString(6, address);
            pStmnt.setString(7, role);
            int rowCount = pStmnt.executeUpdate();
            if (rowCount >= 1) {
                isSuccess = true;
            }
            pStmnt.close();
            cnnct.close();
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return isSuccess;
    }
    
    public CustomerBean queryCustByEmail(String email) {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;

        CustomerBean cb = null;
        try {
            //1.  get Connection
            cnnct = getConnection();
            String preQueryStatement = "SELECT * FROM  CUSTOMER WHERE Email=?";
            //2.  get the prepare Statement
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            //3. update the placehoder with id
            pStmnt.setString(1, email);
            ResultSet rs = null;
            //4. execute the query and assign to the result 
            rs = pStmnt.executeQuery();
            if (rs.next()) {               
                // set the record detail to the customer bean
                cb = new CustomerBean();
                cb.setCustid(rs.getInt(1));
                cb.setEmail(rs.getString(3));
                cb.setPassword(rs.getString(2));
                cb.setFirst_name(rs.getString(4));
                cb.setLast_name(rs.getString(5));
                cb.setGender(rs.getString(6));
                cb.setAddress(rs.getString(8));
            }


            pStmnt.close();
            cnnct.close();
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return cb;
    }
    
    public ArrayList<OrderBean> queryCustOrder(CustomerBean cb) {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        ArrayList<OrderBean> list = new ArrayList<OrderBean>();
        int custID = cb.getCustid();
        OrderBean ob = null;
        try {
            cnnct = getConnection();
            String preQueryStatement = "SELECT * FROM orders WHERE CUSTID=?";

            pStmnt = cnnct.prepareStatement(preQueryStatement);
            pStmnt.setInt(1, custID);
            ResultSet rs = null;
            rs = pStmnt.executeQuery();
            while (rs.next()) {

                ob = new OrderBean();
                //CustomerDB cDB = new CustomerDB(url, username, password);
                //CustomerBean cb = cDB.getCustIdById(rs.getInt("CUSTID"));

                ob.setOrder_id(rs.getInt("ORDER_ID"));
                ob.setCustomer(cb);
                ob.setDeliever_add(rs.getString("DELIEVER_ADD"));
                ob.setDeliever_date(rs.getDate("DELIEVER_DATE"));
                ob.setDeliever_time(rs.getDate("ORDER_TIME"));
                ob.setOrder_option(rs.getString("ORDER_OPTION"));
                ob.setOrder_qty(rs.getInt("ORDER_QTY"));
                ob.setOrder_state(rs.getString("ORDER_STATE"));
                //String preQueryStatement2 = "SELECT * FROM ORDER_PRODUCT WHERE ORDER_ID=?";
                //PreparedStatement pStmnt2 = cnnct.prepareStatement(preQueryStatement2);
                //pStmnt2.setString(1, rs.getString("ORDER_ID"));
                //ResultSet rs2 = pStmnt2.executeQuery();
                //ArrayList<ProductBean> products = new ArrayList<ProductBean>();
                //ProductDB prodDB = new ProductDB(url, username, password);
                //while (rs2.next()) {
                    //set productBean
                //    ProductBean pb = prodDB.getProductById(rs2.getInt("p_id"));
                //    pb.setP_qty(rs2.getInt("p_qty"));
                //    products.add(pb);
                //}
                //ob.setProducts(products);
                list.add(ob);
            }
            pStmnt.close();
            cnnct.close();
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
    public boolean editPassword(String email, String password) {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        boolean isSuccess = false;
        try {
            cnnct = getConnection();
            String preQueryStatement = "UPDATE CUSTOMER SET Password=? WHERE Email=?";
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            pStmnt.setString(1, password);
            pStmnt.setString(2, email);
            //Statement s = cnnct.createStatement();
            int rowCount = pStmnt.executeUpdate();
            if (rowCount >= 1) {
                isSuccess = true;
            }
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (pStmnt != null) {
                try {
                    pStmnt.close();
                } catch (SQLException e) {
                }
            }
            if (cnnct != null) {
                try {
                    cnnct.close();
                } catch (SQLException sqlEx) {
                }
            }
        }
        return isSuccess;
    }
    
    public boolean editAddress(String email, String address) {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        boolean isSuccess = false;
        try {
            cnnct = getConnection();
            String preQueryStatement = "UPDATE CUSTOMER SET Address=? WHERE Email=?";
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            pStmnt.setString(1, address);
            pStmnt.setString(2, email);
            //Statement s = cnnct.createStatement();
            int rowCount = pStmnt.executeUpdate();
            if (rowCount >= 1) {
                isSuccess = true;
            }
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (pStmnt != null) {
                try {
                    pStmnt.close();
                } catch (SQLException e) {
                }
            }
            if (cnnct != null) {
                try {
                    cnnct.close();
                } catch (SQLException sqlEx) {
                }
            }
        }
        return isSuccess;
    }
    public boolean tableExist(Connection conn, String tableName) throws SQLException {
        boolean tExists = false;

        try (ResultSet rs = conn.getMetaData().getTables(null, null, tableName, null)) {
            while (rs.next()) {
                String tName = rs.getString("TABLE_NAME");
                if (tName != null && tName.equals(tableName)) {
                    tExists = true;
                    break;
                }
            }
        }

        return tExists;
    }

    public boolean login(String username, String password) {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        boolean isTrue = false;
        try {
            //1.  get Connection
            cnnct = getConnection();
            String preQueryStatement = "SELECT * FROM  CUSTOMER WHERE EMAIL=? AND PASSWORD=? AND ROLE=?";
            //2.  get the prepare Statement
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            //3. update the placehoder with id
            pStmnt.setString(1, username);
            pStmnt.setString(2, password);
            pStmnt.setString(3, "customer");
            ResultSet rs = null;

            //4. execute the query and assign to the result 
            rs = pStmnt.executeQuery();

            int count = 0;

            if (rs.next()) {
                ++count;
                isTrue = true;
            }

            if (count == 0) {
                isTrue = false;
            }

            System.out.println("Total rows for the query: " + count);

            pStmnt.close();
            cnnct.close();
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return isTrue;
    }
}
