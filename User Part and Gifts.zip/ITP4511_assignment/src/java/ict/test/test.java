/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ict.test;

import ict.bean.CustomerBean;
import ict.bean.GiftRecordBean;
import ict.bean.OrderBean;
import ict.db.CustomerDB;
import ict.db.GiftDB;
import ict.db.GiftRecordDB;
import ict.db.OrderDB;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ccwai
 */
public class test {
    public static void main(String[] args) throws SQLException, IOException{
        String url = "jdbc:derby://localhost/ITP4912_DB";
        String username = "APP";
        String password = "APP";
        CustomerDB db = new CustomerDB(url,username,password);
        //db.addOrder(1, 1, 100, null,null,"OK", "HK", "OK");
        CustomerBean cb = db.queryCustByEmail("abc@gmail.com");
        ArrayList<OrderBean> list = db.queryCustOrder(cb);
        
            System.out.println(list.size());
            
        GiftRecordDB gdb = new   GiftRecordDB(url,username,password); 
        //gdb.createGiftRecordTable();
        ArrayList<GiftRecordBean> gb = gdb.queryGifts("Pending");
        
            System.out.println(gb.size());
            for(GiftRecordBean list1: gb){
                System.out.println(list1.getC_id());
                System.out.println(list1.getG_id());
                System.out.println(list1.getStatus());
            }
        
    }
    
}
